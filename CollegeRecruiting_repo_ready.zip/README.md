# CollegeRecruiting

Gameday Baseball Recruiting Matchmaker
- `web_app/`: Flask app ready for Render (or Railway/Heroku)
- `mac_desktop_app/`: PyWebview wrapper with PyInstaller instructions to build a native macOS .app

## Quick start (local web)
```bash
cd web_app
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
flask --app app.py run
```

## Deploy to Render
Use `render.yaml` or create a Web Service with:
- Build: `pip install -r requirements.txt`
- Start: `gunicorn -b 0.0.0.0:$PORT app:app`
- Set env: `FLASK_SECRET_KEY` (and SMTP vars if desired)
