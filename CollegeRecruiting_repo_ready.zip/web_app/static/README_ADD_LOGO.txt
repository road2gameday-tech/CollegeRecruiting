Place your Gameday_2020_Script-01.png here to show the logo in the UI.
