Mac desktop wrapper using PyWebview + PyInstaller. See commands inside.
